package model;

public class CentroCultivo {

    private int id;
    private String nombre;
    private String localidad;
    private int capacidadToneladas;
    private Estado estado;

    public enum Estado {
        OPERATIVO, MANTENCION, CERRADO
    }

    public CentroCultivo(int id, String nombre, String localidad, int capacidadToneladas, Estado estado) {
        this.id = id;
        this.nombre = nombre;
        this.localidad = localidad;
        this.capacidadToneladas = capacidadToneladas;
        this.estado = estado;
    }

    // Getters y setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getLocalidad() { return localidad; }
    public void setLocalidad(String localidad) { this.localidad = localidad; }

    public int getCapacidadToneladas() { return capacidadToneladas; }
    public void setCapacidadToneladas(int capacidadToneladas) { this.capacidadToneladas = capacidadToneladas; }

    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }

    @Override
    public String toString() {
        return String.format("CentroCultivo{id=%d, nombre='%s', localidad='%s', capacidad=%d, estado=%s}",
                id, nombre, localidad, capacidadToneladas, estado);
    }
}
