package app;

import service.CentroService;
import model.CentroCultivo.Estado;

public class Main {

    public static void main(String[] args) {

        CentroService service = new CentroService();

        service.cargarDesdeArchivo("data/centros.txt");

        System.out.println("\n--- TODOS LOS CENTROS ---");
        service.mostrarTodos();

        System.out.println("\n--- Buscar por localidad: Puerto Montt ---");
        service.buscarPorLocalidad("Puerto Montt").forEach(System.out::println);

        System.out.println("\n--- Filtrar por estado OPERATIVO ---");
        service.filtrarPorEstado(Estado.OPERATIVO).forEach(System.out::println);
    }
}
